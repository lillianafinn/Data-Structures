#include ...
using ...

bool success = false;
bool findall = false;
bool verbose = false;

void show_solution(vector<int> &numbers, vector<int> &operations) {
  write this
}

bool find_solution(vector<int> &numbers, vector<int> &operations, int k=0, int fvalue=0) {
  write this
}

int main(int argc, char *argv[]) {
  command line parsing, data reading
  find_solution: inorder vs anyorder mode
}
