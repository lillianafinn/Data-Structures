#include ...
using namespace std;

typedef unsigned long ulong;

struct credentials {
  void set_salt(string &);
  void set_hash(string &);

  void operator=(const credentials &);
  bool operator==(const credentials &);

  string salt;
  ulong password_hash;
};

void credentials::set_salt(string &username) {
  salt = "Kn0xVi113";
  garble salt using username 
}

void credentials::set_hash(string &password) {
  calculate and set password_hash
}

istream &operator>>(istream &in, credentials &login) {
  implement this

  return in;
}

ostream &operator<<(ostream &out, const credentials &login) {
  implement this

  return out;
}

typedef unordered_map<string,credentials> hashtable;

void write_hashtable(hashtable &H, bool verbose) {
  print details if verbose == true

  read username, password pairs from stdin
    create credentials object
      set salt using username
      set hash using username
    insert username, credentials into hashtable

  open passwd.txt for writing
  check file open was successful
  write hashtable content to file
  close file
}

void read_hashtable(hashtable &H, bool verbose) {
  print details if verbose == true

  open passwd.txt for reading
  check file open was successful

  read username, credentials pairs from passwd.txt
    insert username, credentials into hashtable

  close file
}

int main(int argc, char *argv[]) {
  parse command line options

  hashtable H;
  set max load factor

  if option -create:
    write_hashtable(H, verbose)

  else
  if option -check
    read_hashtable(H, verbose)

	read username, passwor pairs from stdin
      look for username in hashtable

	  if not found
	    print error message
	    continue

	  make copy of username credentials
	  set password_hash to match password

	  if stored hash == new hash
        print access granted
      else
        print error message
    }
  }
}
