#include <iostream>
#include <cstring>
#include <string> 
#include <cstdlib>
using std::cout;
using std::endl; 
using std::cerr; 
using std::cin; 
#include "bst.h"

template <typename Iterator>
void print_forward(Iterator i0, Iterator i1) {
	//cout << "hello";
	if (i0 == i1) {
		//cout << "hello";
	};
	
	while (i0 != i1) {
		//++i0;
		cout << " " << setw(3) << *i0;
		++i0;
	}
	cout << "\n";
}

template <typename Iterator>
void print_reverse(Iterator i0, Iterator i1) {
  //similar to print_forward only decrementing
  if(i0 == i1) return;

  while(i0 != i1){
	//--i0;
	cout << " " << setw(3) << *i0; 
	--i0; 
  }

  cout << "\n";
}

int main(int argc, char *argv[]) {
	//unix> ./Prog7 [-inorder [-range lower upper] | -reverse] < data.txt
	
	bool inorder = false; 
	bool reverse = false; 
	bool range = false; 
	int lower = 0; 
	int upper = 0; 

	if(argc == 5){
		std::string arg1 = argv[1];
		std::string arg2 = argv[2];
		int l = std::atoi(argv[3]); 
		int u = std::atoi(argv[4]);
		if(arg1 == "-inorder") inorder = true;
		if(arg2 == "-range"){
			range = true; 
			lower = l; 
			upper = u;  
		} else{
			inorder = false;
			cerr << "./usage: ./Prog7 [-inorder [-range lower upper] | -reverse ] < data.txt" << endl; 
		}
	}
	
	if(argc == 2){
		std::string arg = argv[1];
		if(arg == "-inorder") inorder = true;
		if(arg == "-reverse") reverse = true; 
	}

	//Populate BST T with data from stdin
	bst<int> T;
	int num;
	int count = 0; 
	while(cin >> num){
		T.insert(num);
		count++; 
	}

	//if no data was read
		//exit
	if(count == 0) return 1; 
	
	
	//TODO:instantiate BST iterators
	bst<int>::iterator p0 = T.begin();
	bst<int>::iterator p1 = T.end(); 

	//T.print();
	//cout << inorder; 
	if (argc == 1) {
		T.print_levelorder();
	} else
	if (inorder) {
		p0 = T.begin();
		p1 = T.end();
	
		//if bounds given, set p0=lower and p1=upper
		if(range){
			p0 = T.lower_bound(lower);
			p1 = T.upper_bound(upper);
		}
		print_forward(p0, p1);
	} else
	//if (doing reverse inorder traversal) {
	if(reverse){
		p0 = T.rbegin();
		p1 = T.rend();

		print_reverse(p0, p1);
	}
}
