#ifndef BST_H
#define BST_H

#include <iostream>
#include <iomanip>
#include <queue> 
using std::cout;
using std::endl;
using std::setw;
using std::queue;


template <class TKey>
class bst {
  struct node {
	node(int id = 0);
    void print();

    TKey key;
    int ID;
    node *parent;
    node *left;
    node *right;
  };

  public:
    class iterator {
      public:
		//default constructor (no argument)
		iterator() : p(NULL) {}

       //operators ++, --, *, ==, and !
	   iterator operator++(){
			//TODO: Hardest one yet
			if(p && p->right){
				p = p->right;
				while(p->left) p = p->left; 
			}
			else{
				node *back = p->parent;
				while(back && p == back->right){
					p = p->parent; 
					back = back->parent; 
				}
				p = back; 
			}
			return p; 
	   }
		
	   iterator operator--(){
		if(p && p->left){
			p = p->left;
			while(p->right) p = p->right;
		}
		else{
			node *back = p->parent; 
			while(back && p == back->left){
				p = p->parent;
				back = back->parent; 
			}
			p = back;
		}
		return p; 
	   }

	   TKey& operator*(){ return p->key;}
		
	   bool operator==(const iterator &rhs){ return p == rhs.p; }
	   bool operator!=(const iterator &rhs){ return p != rhs.p; }

      private:
        friend class bst<TKey>;
        //constructor (with argument)
		iterator(node *n):  p(n) {}

        node *p;
    };

    iterator begin();
    iterator end();

    iterator rbegin();
    iterator rend();

  public:
    bst(): nodeID(0) { Troot=NULL; }
    ~bst() { clear(Troot); }

    bool empty() { return Troot==NULL; }

    void insert(TKey &);  

    iterator lower_bound(const TKey &);
    iterator upper_bound(const TKey &);

    void print_levelorder();
	
	//for private insert function 
	node *parent2 = NULL; 
  private:
    void clear(node *);
    node *insert(node *, TKey &);

    int nodeID;
    node *Troot;
};

//node constructor 
template <class TKey>
bst<TKey>::node::node(int id) : ID(id), parent(NULL), left(NULL), right(NULL) {}


template <class TKey>
void bst<TKey>::node::print() {
	//output node and parent ID information
	cout << setw(3) << ID << setw(3);   
	cout << setw(3) << key << " :" << setw(3);
	if(parent == NULL) {
		cout << " ROOT" << setw(4); 
	} else cout << "P=" << setw(3) << parent->ID << setw(3); 

	if (left)  cout << " L=" << setw(3) << left->ID;
	else       cout << "      ";
	if (right) cout << " R=" << setw(3) << right->ID;
	else       cout << "      ";

	cout << "\n";
}

//iterators begin, end, rbegin, rend
template<class TKey>
typename bst<TKey>::iterator bst<TKey>::begin() {
	node *n = Troot;
	while (n != NULL && n->left != NULL) n = n->left;
	return iterator(n);
}

template<class TKey>
typename bst<TKey>::iterator bst<TKey>::end() {
	return iterator(NULL);
}
template<class TKey>
typename bst<TKey>::iterator bst<TKey>::rbegin() {
	node *n =  Troot;
	while(n != NULL && n->right != NULL) n = n->right;
	return iterator(n);
}

template<class TKey>
typename bst<TKey>::iterator bst<TKey>::rend() {
	return iterator(NULL);
}

template <class TKey>
void bst<TKey>::clear(node *n){
	if(n){
		clear(n->left); 
		clear(n->right); 
		delete n; 
		n = NULL; 
	}
}

template <class TKey>
void bst<TKey>::insert(TKey &key){
	//public insert
	//calls private insert function
    Troot = insert(Troot, key);
}

template <class TKey>
class bst<TKey>::node *bst<TKey>::insert(node *n, TKey &key){
	if(n == NULL){
		//creates new node and assigns key and parent 
		n = new node(nodeID++); 
		n->key = key; 
		if(parent2 != NULL){
			n->parent = parent2;
		}
	}
	else if(key == n->key){}
	else if(key < n->key){
		parent2 = n; 
		n->left = insert(n->left, key); 
	}else {
		parent2 = n; 
		n->right = insert(n->right, key); 
	}
	return n ; 
}

//more iterators for lower_bound and upper_bo
template <class TKey> 
typename bst<TKey>::iterator bst<TKey>::lower_bound(const TKey &key){
	node *n = Troot; 
	node *ans = NULL; 
	while(n != NULL){
		if(n->key >= key){
			ans = n; 
			n = n->left; 
		}
		else n = n->right; 
	}

	return iterator(ans); 
}

template <class TKey>
typename bst<TKey>::iterator bst<TKey>::upper_bound(const TKey &key){
	node *n = Troot; 
	node *ans = NULL; 
	while(n != NULL){
		if(n->key > key) ans = n;
		if(n->key <= key){
			//ans = n; 
			//cout << n->key << endl; 
			n = n->right;
			//ans = n; 
		}
		else{
			//ans = n; 
			n = n->left;
		}
	}
	return iterator(ans); 
}

template <class TKey>
void bst<TKey>::print_levelorder(){
	//cout << "hello";
	if(Troot == NULL){
		//cout << "hey"; 
		return; 
	}
	queue<node *> q; 
	node *t; 

	q.push(Troot); 
	while(!q.empty()){
		t = q.front(); 
		q.pop(); 
		
		//cout << t->key;
		t->print(); 
		if(t->left) q.push(t->left);
		if(t->right) q.push(t->right);
	
	}

}

#endif
