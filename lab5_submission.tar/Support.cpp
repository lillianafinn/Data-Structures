//recived help with Sydney

#include <iostream>
#include <fstream> 
#include <algorithm>
#include <cmath>
#include <string>
using std::cout;
using std::endl;
using std::cerr;
using std::ifstream; 
using std::fstream; 
using std::ofstream; 
#include "Support.h"

//ppm constructor()
ppm::ppm() : magicid("P6"), maxvalue(255), block_size(256) {}

//TODO:figure out if you nned to add img and block_size
ppm::ppm(const ppm &other) {
	magicid = other.magicid; 
	Nrow = other.Nrow;
	Ncol = other.Ncol;
	maxvalue = other.maxvalue; 
	block_size = other.block_size; 

	img = new RGB[Nrow * Ncol];
	for(int i = 0; i < Nrow * Ncol; i++){
		img[i] = other.img[i];
	}
}

	
ppm::~ppm() {
    delete[] img;
}

RGB *ppm::operator[](int num){ return &img[num * Ncol]; }

void ppm::set_bs(int bs){
	block_size = bs;
}

void ppm::read(const string &filename){
	ifstream fin(filename.c_str());
	if(!fin.is_open()){
		cerr << "Error: Could not open file! " << endl; 
	}
	
	//read header 
	//skip blanks?
	fin >> magicid; 
    if (magicid != "P6") {
        cerr << "Error: Invalid magic identifier " << magicid << endl;
    }
	
	fin >> Ncol >> Nrow >> maxvalue; 
	if (maxvalue != 255) {
        cerr << "Error: Invalid max value " << maxvalue << endl;
    }	
	img = new RGB[Nrow*Ncol];
	
	while(fin.get() != '\n'){}
	
	int nrgb = block_size; 
	int nrgb_read;		//pixels read per line
	int npixels_read = 0; 
	//int total_pixels = Nrow * Ncol * sizeof(RGB); 

	unsigned char *rgb_ptr; 
	unsigned char buf[3 * nrgb];


	while(1){
		fin.read((char*)buf, 3*nrgb);
		//cout << buf[0];
		nrgb_read = fin.gcount()/3; 
		//cout << nrgb_read << endl; 
		if(nrgb_read == 0 && fin.eof()) break; 

		rgb_ptr = buf; 
		for(int i = npixels_read; i < nrgb_read+npixels_read; i++){
				img[i].R = *rgb_ptr++;
				img[i].G = *rgb_ptr++; 
				img[i].B = *rgb_ptr++; 
				//cout << *rgb_ptr;
		}
		npixels_read += nrgb_read; 
	}

  //close file
  fin.close(); 
}

void ppm::write(const string &filename){
	//update file name
	//cout << filename.rfind('.'); 
	string out_file = filename;
	out_file.insert(filename.rfind('.'), "_mod");	//open file -- error check

	ofstream fout(out_file.c_str()); 
	if(!fout.is_open()){
		cerr << "Error: Could not open file!" << endl; 
	}
  
	//write header
	fout << magicid << endl;
	fout << Ncol << " " << Nrow << endl;
	fout << maxvalue << endl; 
	
	//TODO:write image (block size)
	int nrgb = block_size; 
	//int nrgb_read = 0;
	int npixels_read = 0; 
	int total_pixels = Nrow * Ncol; 

	//unsigned char *rgb_ptr; 
	unsigned char buf[3 * nrgb];

	//TODO: figure out how to fix the buffer	
	while(npixels_read < total_pixels){
		for(size_t i = 0; i < sizeof(buf); i += 3){
				buf[i] = img[npixels_read].R;
				buf[i+1] = img[npixels_read].G;
				buf[i+2] = img[npixels_read].B;
				npixels_read += 1; 
		}  

		fout.write((char*)buf, sizeof(buf)); 
	}

	//close file
	fout.close();
	//cout << ":)"; 
}

//conversions
//
//need to turn into an int then back to an unsigned char
void gray(ppm &img) {
	for(int i = 0; i < img.get_Nrow(); i++){
		for(int j = 0; j < img.get_Ncol(); j++){
			//RGB temp = img[i][j];
			int red = img[i][j].R; 
			int green = img[i][j].G; 
			int blue = img[i][j].B; 
			int Y = ((red + green + blue)/3);
			//cast back to unsigned char switch order
			//y = img.r = img.g = img.b
			img[i][j].R = img[i][j].G = img[i][j].B = (unsigned char)Y; 


		}
	}
  //change RBG to (R+G+B)/3
}

void flip(ppm &img) {
  //flip image left-to-right
  for(int i = 0; i < img.get_Nrow(); i++){
	for(int j = 0; j < img.get_Ncol()/2; j++){
		std::swap(img[i][j], img[i][img.get_Ncol()-j-1]);
		//RGB temp = img[i][j];
		//img[i][j] = img[i][img.get_Ncol()-j-1];
		//img[i][img.get_Ncol()-j-1] = temp;
	}
  }
}

void draw(ppm &img, int K) {
	//extract drawing of image
	//this uses copy constructor
	ppm img_copy = img; 

	for(int i = 0; i < img.get_Nrow(); i++){
		for(int j = 0; j <img.get_Ncol(); j++){
			//determine gray scale for each pixel
			int Ymax = 0;
			for(int ci = -K; ci <= K; ci++){
				for(int cj = -K; cj <= K; cj++){
					 int di = i + ci;
					 int dj = j + cj;
					 if (di >= 0 && di < img.get_Nrow() && dj >= 0 && dj < img.get_Ncol()) {
                        //RGB pixel = img_copy[di][dj];
						int red = img_copy[di][dj].R; 
						int green = img_copy[di][dj].G; 
						int blue = img_copy[di][dj].B; 
                        int Y = ((int)(red + green + blue) / 3);
                        if (Y > Ymax) Ymax = Y;
                    }
				}
				
			}
			//RGB pixel = img[i][j];
			int red = img[i][j].R; 
			int green = img[i][j].G; 
			int blue = img[i][j].B; 
            int Y = ((red + green + blue) / 3);
            img[i][j].R = img[i][j].G = img[i][j].B = (unsigned char)(255 - (Ymax - Y));
		}
	} 
}

void lens(ppm &img, float rho) {
	//apply spherical transformation
	ppm img_copy = img; 
	int ci = img.get_Nrow()/2; 
	int cj = img.get_Ncol()/2;
	float rmax = std::min(ci, cj); 

	for(int i = 0; i < img.get_Nrow(); i++){
		for(int j = 0; j < img.get_Ncol(); j++){
			int di = i - ci; 
			int dj = j-cj; 
			int r = sqrt(di*di + dj*dj);

			if(r < rmax){
				float z = sqrt(rmax*rmax - r*r); 
				float dzi = di/sqrt(di*di + z*z); 
				float dzj = dj/sqrt(dj*dj + z*z);
				
				float bi = (1.0-1/rho) * (asin(dzi)); 
				float bj = (1.0-1/rho) * (asin(dzj)); 
				int ip = ((int)(i-z*tan(bi)+0.5)); 
				int jp = ((int)(j-z*tan(bj)+0.5));

				img[i][j] = img_copy[ip][jp]; 

			}
		}
	}
}
