#include <vector>
#include <set>

class prime_partition {
  public:
    prime_partition();

    //other functions needed
	void set_verbose(bool v);
	void set_reverse(bool r);

    void find_partition(int num);

  private:
    void expand_pset(int num);
    bool find_partition(int num, int terms);

    //pset and other data members
	std::set<int> pset; 
	std::vector<int> partition; 
	int pset_max; 
	bool verbose; 
	bool reverse; 
};
