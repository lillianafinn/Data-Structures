#include <iostream>
using namespace std;

#include "Support.h"

int main(int argc, char *argv[])
{
	//command line arguments
    bool verbose = false;
    bool reverse = false;

    //error message
    if (argc == 1) {
        cerr << "Usage: " << argv[0] << " -forward|-reverse [-verbose]" << std::endl;
        return 1;
    }

    //checking command line prompt
    if (argc == 3) {
        if (string(argv[1]) == "-forward") reverse = false;
        if (string(argv[1]) == "-reverse") reverse = true;
        if (string(argv[2]) == "-verbose") verbose = true;
    }
    else if (argc == 2) {
        if (string(argv[1]) == "-forward") reverse = false;
        if (string(argv[1]) == "-reverse") reverse = true;
    }

    prime_partition goldbach;
    goldbach.set_reverse(reverse);
    goldbach.set_verbose(verbose);

    while (true) {
        //stdin::  prompt for number
        cout << "number: = ";
        int number;
        cin >> number;

        //TODO:check for end-of-file
        if (cin.fail()) {
            cin.clear();
            cin.ignore(256, '\n');
            continue;
        }

        //check number is not too small
        if (number < 6) cout << "Too small. Try again." << endl;

        goldbach.find_partition(number);

    }
	return 0;
}
