#include <iostream> 
#include <vector>
#include <algorithm> 
using namespace std; 

bool success = false;
bool findall = false;
bool verbose = false;

void show_solution(vector<int> &numbers, vector<int> &operations) {
	//cout << ":)";
		
	if(verbose == true){
		//cout << ":)";
		cout << numbers[0]; 

		for(size_t i = 0; i < operations.size(); i++){
			cout << (char)operations[i] << numbers[i+1]; 
		}
		cout << "=" << numbers.back() << " "; 
	}  
	
	//cout << ":)";
	//cout << operations.size();
	for(size_t i = 0; i < operations.size(); i++){
		cout << (char)operations[i]; 		
	}
	cout << endl; 
	
}

bool find_solution(vector<int> &numbers, vector<int> &operations, int k=0, int fvalue=0) {
	//int target = numbers.back(); 
	//cout << ":)";
	if(k == 0){
		operations.clear(); 
		return find_solution(numbers, operations, 1, numbers[0]);
	}
	
  //the second if statement is to cout the information 
  if(k == (int)numbers.size()-1){
	 // cout << fvalue << " ";
	if(fvalue == numbers.back()){
		//cout << ":)";
		//success = true; 
		if(success == false && findall == false){ 
			show_solution(numbers, operations);
		}
		success = true;
		if(findall == true){
			show_solution(numbers, operations);
			//cout << ":|";
		}

		return true;
	}
	return false; 
  }

  const char options[] = {'*', '/', '+' , '-'};
  //int count = 1; 
  //cout << ":)";
  for(int i = 0; i < 4; i++){
	operations.push_back(options[i]);
	//cout << options[i];
	int value = fvalue;
	
	//does the operation onto value; 
	if(options[i] == '+') value += numbers[k];
	if(options[i] == '-') value -= numbers[k]; 
	if(options[i] == '*') value *= numbers[k]; 
	if(options[i] == '/') value /= numbers[k]; 
	
	//count++;
	//cout << value << " :)" << endl; 

	if((find_solution(numbers, operations, k+1, value)) == true){
		//cout << value << " ";
		operations.pop_back(); 
		return !findall; 
	}
	operations.pop_back(); 
  }
	
  return false; 
}

int main(int argc, char *argv[]) {
	bool inorder = false; 
	bool anyorder = false; 

	if(argc < 3) {
		//cerr << ";)";
		cerr << "./Prog6 -inorder|anyorder -1|N [-verbose] < numbers.txt";
		return 1; 
	}
	
	//argument variables
	string arg1 = argv[1];
	string arg2 = argv[2];
	
	//checking arguments in command line and either assigning variables true or false, or outputing an error statement
	if(arg1 == "-inorder") inorder = true; 
	else if(arg1 == "-anyorder") anyorder = true;
	else {
		//cerr << ";)";
		cerr << "./Prog6 -inorder|anyorder -1|N [-verbose] < numbers.txt";
		return 1; 
	}
	
	//argument 2
	if(arg2 == "-1") findall = false; 
	else if(arg2 == "-N") findall = true;
	else{
		cerr << "./Prog6 -inorder|anyorder -1|N [-verbose] < numbers.txt";	
	}
	
	//argument 3
	if(argc == 4){
		string arg3 = argv[3];
		if(arg3 == "-verbose") verbose = true;
	} 
	
	//cout << verbose; 
	//reading in data
	vector<int> nums;
	int n; 
	while(cin >> n) {
		nums.push_back(n); 
		//cout << n << " ";
	}

	if(nums.size() < 3) {
		cout << nums[0] << "=" << nums[0];
	}

	if(inorder){
		vector<int> operations;
		find_solution(nums, operations);
	}
	else if(anyorder){
		//vector<int> operations;
		sort(nums.begin(), nums.end()-1);
	
		do{
			vector<int> operations;
			find_solution(nums, operations);
		} while(next_permutation(nums.begin(), nums.end()-1));
	}

	if(!success) cout << "No solution found" << endl; 


}
