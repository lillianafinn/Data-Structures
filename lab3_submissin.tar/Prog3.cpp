#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cstdlib> 
#include "Support.h"
#include <vector> 
using namespace std; 

//DO NOT #include Support.cpp !!!
//./numbers [n][m]
//n = number of random numbers [default = 10]
//m = range of random numbers [default = 20]

int main(int argc, char *argv[]) {
	bool sorted = false; 
	bool unique = false; 
	bool verbose = false; 
	
	for(int i = 1; i < argc; i++){
		string arg = argv[i]; 
		if(arg == "-sorted") sorted = true; 
		if(arg == "-unique") unique = true; 
		if(arg == "-verbose") verbose = true; 
	}
	
	int num; 
	isprime primer(verbose); 
	vector<int> prime_nums; 

	while(cin >> num) {
		//debug statement
		//cout << num << " ";
		if(primer(num) == true){
			prime_nums.push_back(num); 
		}
	}

	// alters the list depending if the user provided input
	if(sorted || unique){
		sort(prime_nums.begin(), prime_nums.end()); 
	}

	if(unique){
		vector<int>::iterator ip; 
		ip = std::unique(prime_nums.begin(), prime_nums.end()); 
		prime_nums.erase(ip, prime_nums.end()); 
		//prime_nums.erease(unqiue(prime_nums.begin(), prime_nums.end()), prime_nums.end());
	}
	
	//use 4 characters per number
	//max of 20 numbers per line
	for(size_t i = 0; i < prime_nums.size(); i++){
		if((i % 20 == 0) && i != 0){
			cout << "\n"; 
		}
		cout << setw(4) << prime_nums[i]; 
	}
	
	return 0; 
}

