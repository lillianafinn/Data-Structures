 Add location and list member function code here.
