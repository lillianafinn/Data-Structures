#include <iostream> 
#include <fstream> 
#include <string>
#include <cstdlib>
using std::cerr;
//using std::stoi;
#include "Support.h"

int main(int argc, char *argv[]) {
  ppm image; 
  int block_size = 256;
  int K = 1;
  float rho = 1.0;

  bool Gray = false; 
  bool Flip = false; 
  bool Draw = false; 
  bool Lens = false; 

  if(argc == 1){
	cerr << "usage: ./Prog5 [-gray] [-flip] [-draw K] [-lens z] [-bs nbytes] image.ppm";
	return 1; 
  }
 
  for(int i = 1; i < argc; i++){
	string arg = argv[i];
	if(arg == "-gray") Gray = true; 
	if(arg == "-flip") Flip = true;
	if(arg == "-draw"){
		if(i+1 < argc){
			if(atoi(argv[i+1]) >= 1) {
				Draw = true;
				K = atoi(argv[i+1]);
				i++;
			}
		} else cerr << "usage: ./Prog5 [-gray] [-flip] [-draw K] [-lens z] [-bs nbytes] image.ppm";
	}
	if(arg == "-lens"){
		if(i+1 < argc){
			if(atof(argv[i+1]) > 1.0 && atof(argv[i+1]) <= 2.0){
				Lens = true; 
				rho = atof(argv[i+1]);
				i++;
			}
		} else cerr << "usage: ./Prog5 [-gray] [-flip] [-draw K] [-lens z] [-bs nbytes] image.ppm"; 
	}
	if(arg == "-bs") block_size = atoi(argv[i+1]);
  }

  string filename = argv[argc-1];
  image.read(filename);

  //set fileio block size
  image.set_bs(block_size); 


  if(Gray) gray(image);

  if(Flip) flip(image); 

  if(Draw) draw(image, K); 

  if(Lens) lens(image, rho); 

  //write image
  image.write(filename);
}
