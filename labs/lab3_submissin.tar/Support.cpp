#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
#include "Support.h"

//write code for isprime member functions

/* declared in header file
 * isprime(bool verbose=false);
 * bool operator()(int);
 *
 * private:
 * void expanded_known_primes(int);
 *
 * bool verbose;
 * vector<int> known_primes;
 */
// verbose input option: if user inputs -verbose then add "updating ___" & ** adding __ (Num = __)

isprime::isprime(bool verbose) : verbose(verbose) {
	//known_primes.push_back(2);
	known_primes.assign(1,2);
}

bool isprime::operator()(int num){
	if(num < 2) return false;

	if(num > known_primes.back()) expand_known_primes(num);
	return std::binary_search(known_primes.begin(), known_primes.end(), num);
}

void isprime::expand_known_primes(int num){
	//this function is used to determine where a number is prime and to add prime numbers to the known vector untill the new number being tested is on the list or the list contains a prime number larger
	// 1. set the potential next prime number Q equal to the next odd number larger than the larger than the largest known prime number (p). That is, for P even, Q = P + 1 while for P odd, Q = P +2
	// 2. check whether Q is prime by doing a modulo check for the sequence 3, 5, 7, .... , sqrt(Q)
	//		This sequence is of odd numbers up to sqrt(Q)
	// 3. If all modulo checks fail, Q is added to the list of known prime numbers
	// 4. This process is repeated for Q = Q + 2 until a prime number has been producedwhich is large enough


	//if it is prime then add to vector else continue
	//1.
	int N = 0; 
	int P = known_primes.back();
	int Q = 0;
	if(P % 2 == 0) {
		Q = P + 1;
		N++;
	}
	else {
		Q = P + 2;
		N++;
	}

	if(verbose) cout << "updating " << num << endl; 

	while(known_primes.back() < num){
		bool is_prime_num = true;
		for(int i = 3; i <= sqrt(Q); i+= 2){
			N++;
			if(Q % i == 0){
				is_prime_num = false;
				break; 
			}
			//N++;
		}

		if(is_prime_num) {
			known_primes.push_back(Q); 
			if(verbose){
				//known_primes.push_back(Q); 
				cout << "** adding " << Q << " (N=" << N << ")" << endl;
			}
			N = 0;
		}

			
		Q = Q + 2;

	}
}

