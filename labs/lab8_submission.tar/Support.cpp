#include <iostream> 
#include <cmath>
#include <set>
#include <algorithm>
using namespace std;

#include "Support.h"

prime_partition::prime_partition() : pset_max(2), verbose(false), reverse(false) {
  pset.insert(2); 
}

void prime_partition::set_verbose(bool v){
	verbose = v; 
}

void prime_partition::set_reverse(bool r){
	reverse = r; 
}

void prime_partition::find_partition(int number) {
	//cout << ":)" << endl;
	if (pset_max < number) {
		//expand pset to cover number
		//cout << number;
		expand_pset(number);
	}

    if (verbose) {
      //print contents of pset
	  //print contents of pset
        //traverse through pset and print out the numbers
		set<int>::iterator p0 = pset.begin();
		set<int>::iterator p1 = pset.end();
        while (p0 != p1) {
            cout << *(p0++) << " ";
        }
		cout << std::endl; 
	}
	
	//clears vector
	partition.clear();
	//call recursive find_partition(number, 0) 
	bool found = find_partition(number,0);
	//cout << found << endl; 
    if(found){
		if (!verbose){
			//cout << "hello"; 
			cout << "3: " << partition[0];
			for (size_t i = 1; i < partition.size(); i++) {
				cout << "+" << partition[i];
			}
			cout << std::endl;
		}
	}
    
}

void prime_partition::expand_pset(int num) {
	if (num <= pset_max) return;
    int next_prime;
    if (pset_max % 2 == 0) next_prime = pset_max+1; //(avoid even numbers)
    else next_prime = pset_max+2;

    //if number is already in list then do nothing
    while(pset_max < num){
        bool is_prime_num = true;
        for(int i = 3; i <= sqrt(next_prime); i+= 2){
            //N++;
            if(next_prime % i == 0){
                //insert next_prime into pset, update pset_max
                is_prime_num = false;
                break;
            }
            //N++;
        }

        if(is_prime_num) {
            pset.insert(next_prime);
            pset_max = next_prime;

            //N = 0;
        }

        next_prime = next_prime + 2;

    }
}

bool prime_partition::find_partition(int num, int terms) {
	if (verbose) {
		cout << terms+1 << " :";
		for(int i = 0; i < terms; i++){
			cout << partition[i] << "+"; 
		}
		cout << num << endl; 
    }

	//base case(s)
    //check if second term too small to be sum of primes
	if(terms == 1 && num < 4){
		return false; 
	}

    //check if last term is in pset
    if (terms == 2) {
		//cout << ":)"; 
		if(pset.find(num) != pset.end()){
			partition.push_back(num);
			return true; 
		}
		return false; 
	}
    

	if (reverse == false) {
         //k < upper_bound(num-1)
        set<int>::iterator k0 = pset.begin();
        set<int>::iterator k1 = pset.upper_bound(num-1);
        
		while(k0 != k1) {
             //add k to partition
            partition.push_back(*k0);
			
			if (find_partition(num-*k0, terms+1) == true) {
				//cout << "hello";
				partition.pop_back();  
				return true;
            }

			//remove k from partition
            partition.pop_back();
			++k0;
        }
    } else {
         if (reverse == true) {
              /*similar to forward mode only backwards: start at the
              end and work toward the beginning, use do-while loop
              instead of a while loop, and decrement your iterator
              instead of incrementing it -- read the assignment
              description multiple times*/
          
              set<int>::iterator k0 = pset.upper_bound(num-1);
			  set<int>::iterator k1 = pset.begin(); 

              do {
                  --k0; 
				  partition.push_back(*k0);
                  if (find_partition(num - *k0, terms+1) == true) {
					  //cout << "hello"; 
					  partition.pop_back(); 
					  return true;
                  }

                  partition.pop_back();

                  //--k0;
              } while (k0 != k1);
            }
      }
	  return false; 
}
