/* Lab 1 for CS202
 *Program 1B
 *Due Data: Feb 4th, 2025
 *Take a weather file and extract the data and assign it to the location and data
 *objects that are defined
 *
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <vector>
#include <iomanip>
using namespace std;

struct location {
    string city;
    string state;
    string geocode;
};

struct Data {
    int month;
    float precip;
    int temp;
};

//class
class summary {
    public:
        summary();
        bool empty();
        void set_station(const location &);
        void incorporate_data(const Data &);

        void print_station();
        void print_data();

    private:
        location station;

        int N;

        float total_precip;
        float max_precip;
        float min_precip;

        int total_temp;
        int max_temp;
        int min_temp;
};


summary::summary() : station(), N(), total_precip(), max_precip(), min_precip(), total_temp(), max_temp(), min_temp() {}

int geocode_to_index(const string &geocode) {
    return (geocode[0]-'A') + 26*(geocode[1]-'A') + 676*(geocode[2]-'A');
}

void summary::set_station(const location & loc) {
    this->station = loc;
};

void summary::incorporate_data(const Data & d){
    N++;
    total_precip += d.precip;
	//max and min precip
    if(d.precip > max_precip) max_precip = d.precip;
	if(N == 0 && min_precip == 0){
		min_precip = d.precip; 
	}
	else if(d.precip < min_precip){
		min_precip = d.precip;
	}
	
	total_temp += d.temp; 
	//max and min temp
    if(d.temp > max_temp) max_temp = d.temp;
	if(min_temp == 0){
		min_temp = d.temp; 
	}
	else if(d.temp < min_temp){
		min_temp = d.temp;
	}

}

void summary::print_station(){
    cout << station.city << ", " << station.state << " (" << station.geocode << ")"  << endl;

}
void summary::print_data(){
	cout << fixed << setprecision(2); 
    cout << total_precip << " " << (total_precip/N) << " " << max_precip << " " << min_precip << " : ";
    cout << (total_temp/N) << " " << max_temp << " " << min_temp << endl;
}

bool summary::empty() {
    if(station.geocode == "") return true;
    else return false;
}


void extract_values(string &line, location & l, Data & d) {
    //changes certain values
    for (int i = 0; i < line.size(); i++) {
        if (line[i] == ' ') {
            line[i] = '_';
        }
        if (line[i] == ',') {
            line[i] = ' ';
        }
    }
    //extracts data
    stringstream sin(line);
    sin >> d.month  >> l.city >> l.state >> l.geocode >> d.precip >> d.temp;

}

int main() {
    //variables
    string line; //for get line
    location loc;
    Data d;
    
	//creates vector for summary class
    //ask how to assign information and access it using classes and structs
    vector<summary> info(17576);

    while (getline(cin,line)) {
        extract_values(line, loc, d);

        //used to find the location
        int gCode = geocode_to_index(loc.geocode);

        // Checks to see if the station has been created in the vector or not
        if (info[gCode].empty()) {
            info[gCode].set_station(loc); // Set the station if it's empty
			info[gCode].incorporate_data(d);
        }
		else{
			info[gCode].incorporate_data(d);
		}

    }

    for(int i = 0; i < info.size(); ++i) {
        if (info[i].empty() == false) {
            info[i].print_station();
            info[i].print_data();
        }
    }



    return 0;
}


