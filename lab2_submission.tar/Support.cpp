//Add location and list member function code here.
//recieved assistance from the Sydney

#include <iostream> 
#include <limits> 
#include <iomanip>
#include "Support.h"
using namespace std;


// constructor
list::node::node(const location &n_station): 
        N(new int[12]),
        next(),
        station(n_station),
        total_precip(new float[12]),
        max_precip(new float[12]),
        min_precip(new float[12]),
        total_temp(new int[12]),
        max_temp(new int[12]),
        min_temp(new int[12]) {};

list::node::~node() {
        delete[] N;
        delete[] total_precip;
        delete[] max_precip;
        delete[] min_precip;
        delete[] total_temp;
        delete[] max_temp;
        delete[] min_temp;
}


list::list() {
        head = new node;
}

list::~list() {
	node *temp = head; 
	
	while(temp != NULL){
		node* dummy = temp; 
		//increments temp before delete prior node
		temp = temp->next; 
		delete dummy; 
	}
}



void list::node::print_station() const{
        const string header(42, '-');
        cout << header << endl;
			cout << station.city << ", " << station.state << " (" << station.geocode << ")" << endl;
			cout << header << endl;
	};

void list::node::print_data() const{
		string months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

			cout << fixed << setprecision(2);
			for (int i = 0; i < 12; i++) {
				if(N[i] == 0){
					N[i] = 1; 
				}
				cout << months[i] << ": ";
				cout << total_precip[i] << " " << (total_precip[i] / N[i]) << " " << max_precip[i] << " " << min_precip[i] << " : ";
				cout << (total_temp[i] / N[i]) << " " << max_temp[i] << " " << min_temp[i] << endl;
			}
};

//this is the most complex function, will take the longest
void list::insert(const location &loc, const data &d) {
		node *p1 = head;
		node *p2 = head->next; 
	
		//bool stationAdded = false; 
		while (p2 != NULL){  
			 
			if (p2->station == loc) {
				//cout << "station: " << p2->station.city;
				//stationAdded = true; 
				break; 
			}

			if (p2->station < loc) {
				//stationAdded = true; 
				//cout << "this station is less than location"; 
				//if station is meant to be inserted here then create new node and link to list
				p2 = new node(loc);
				//node *new_node = new node(loc); 
				
				//link node to the list
				p2->next = p1->next; 
				p1->next = p2;
				
				//new_node->next = p2;
				//p1->next = new_node; 
				break; 

			}
			
			//increment pointers
			p1 = p2;
			p2 = p2->next;
			//p1 = p2; 
			
		}

		if(p2 == NULL){
			//cout << "station added"; 
			p2 = new node(loc); 
			p1->next = p2; 
			p2->next = NULL; 
			//p1->next = p2;
		}
	
		//incorporate data
		if(d.month-1 >= 0 && d.month-1 <= 12){
			p2->N[d.month - 1]++;
			
			p2->total_precip[d.month - 1] += d.precip;
			//cout << "total precip: " << p2->total_precip[d.month-1];
			//max and min precip
			if (d.precip > p2->max_precip[d.month - 1]) p2->max_precip[d.month - 1] = d.precip;
			
			if(p2->min_precip[d.month-1] == 0 && p2->N[d.month-1] == 1) p2->min_precip[d.month-1] = d.precip; 
			else if (d.precip < p2->min_precip[d.month - 1]) {
				p2->min_precip[d.month - 1] = d.precip;
			}

			p2->total_temp[d.month - 1] += d.temp;
			//max and min temp
			if (d.temp > p2->max_temp[d.month - 1]) p2->max_temp[d.month - 1] = d.temp;
			if (p2->min_temp[d.month - 1] == 0) {
				p2->min_temp[d.month - 1] = d.temp;
			} else if (d.temp < p2->min_temp[d.month - 1]) {
				p2->min_temp[d.month - 1] = d.temp;
			}
		}
		//debug statement
		//p2->print_station();
		//p2->print_data(); 
		
	};

	void list::print(const char *target_location) {
			node *temp = head->next;

			if (target_location != NULL) {
				/*if(temp == NULL){
					cout << "temp is null"; 
				} */
				while (temp != NULL) {
					//cout << "made into the while loop";
					//cout << "target location: " << target_location;
					string target = target_location; 
					if (temp->station.state == target || temp->station.geocode == target || temp->station.city == target) {
									
							temp->print_station();
							temp->print_data();
							//break; 
					}
					//cout << "loop 1";
					temp = temp->next; 
				}
			} else {
				while (temp != NULL) {
						temp->print_station();
						temp->print_data();
						//cout << "loop 2";
						temp = temp->next;
				}
			}
};

//operators
bool location::operator<(const location &rhs) const {
			if (this->state == rhs.state) {
					return this->city > rhs.city;
        }
        return this->state > rhs.state;
}

bool location::operator==(const location &rhs) const {
	return this->geocode == rhs.geocode && this->city == rhs.city && this->state == rhs.state;
}

